// Eerst haal ik wat HTML-elementen op die ik nodig heb
const searchInput = document.getElementById('search');
const pokemonList = document.getElementById('pokemon-list');
const sortAscButton = document.getElementById('sort-asc');
const sortDescButton = document.getElementById('sort-desc');

// Maak een nieuwe knop voor favorieten tonen
const filtersDiv = document.getElementById('filters');
const toggleFavoritesBtn = document.createElement('button');
toggleFavoritesBtn.id = 'toggle-favorites';
toggleFavoritesBtn.textContent = '❤️ Favorieten tonen';
filtersDiv.appendChild(document.createElement('br')); // voor nieuwe regel
filtersDiv.appendChild(toggleFavoritesBtn);

let allPokemons = [];
let favoritePokemons = JSON.parse(localStorage.getItem('favorites')) || [];
let showingFavorites = false; // houdt bij of we favorieten tonen

// Haal de eerste 20 Pokémon op van de API
async function fetchPokemons() {
  const res = await fetch('https://pokeapi.co/api/v2/pokemon?limit=20');
  const data = await res.json();
  return data.results; // Alleen de lijst met namen en URLs
}

// Haal alle details van 1 Pokémon op (zoals stats, abilities, image...)
async function fetchPokemonDetails(url) {
  const res = await fetch(url);
  return await res.json();
}

// Toon Pokémon kaarten, afhankelijk van de gegeven lijst
async function displayPokemons(pokemonArray) {
  pokemonList.innerHTML = ''; // Eerst leegmaken

  if (pokemonArray.length === 0) {
    pokemonList.innerHTML = '<p>Geen Pokémon gevonden.</p>';
    return;
  }

  for (let pokemon of pokemonArray) {
    const details = await fetchPokemonDetails(pokemon.url);
    const { name, sprites, types, stats, abilities } = details;

    const card = document.createElement('div');
    card.className = 'pokemon-card';

    // Prijs genereren (random tussen 5 en 20 euro)
    const price = (Math.random() * 15 + 5).toFixed(2);

    // Als we favorieten tonen, laat knop verwijderen zien, anders toevoegen
    const isFavorite = favoritePokemons.includes(name);
    const favButtonText = showingFavorites ? '💔 Verwijder uit favorieten' : '❤️ Toevoegen aan favorieten';

    card.innerHTML = `
      <h3>${name.toUpperCase()}</h3>
      <img src="${sprites.front_default}" alt="${name}">
      <p><strong>Type:</strong> ${types.map(t => t.type.name).join(', ')}</p>
      <ul>
        ${stats.map(stat => `<li><strong>${stat.stat.name}:</strong> ${stat.base_stat}</li>`).join('')}
      </ul>
      <p><strong>Vaardigheden:</strong> ${abilities.map(a => a.ability.name).join(', ')}</p>
      <p class="price" style="font-weight:bold;">Prijs: €${price}</p>
      <button class="favorite-btn" data-name="${name}">${favButtonText}</button>
      <button class="add-to-cart-btn" data-name="${name}" data-price="${price}" style="margin-left:10px;">🛒 Koop</button>
    `;

    pokemonList.appendChild(card);
  }

  // Knoppen voor favorieten toevoegen / verwijderen activeren
  document.querySelectorAll('.favorite-btn').forEach(button => {
    button.addEventListener('click', () => {
      const name = button.getAttribute('data-name');
      if (showingFavorites) {
        removeFromFavorites(name);
      } else {
        addToFavorites(name);
      }
    });
  });

  // Knoppen voor winkelmand toevoegen activeren
  document.querySelectorAll('.add-to-cart-btn').forEach(button => {
    button.addEventListener('click', () => {
      const name = button.getAttribute('data-name');
      const price = button.getAttribute('data-price');
      addToCart(name, price);
    });
  });
}

// Toon een popupmelding onderaan het scherm
function showPopup(message) {
  const popup = document.getElementById('popup');
  popup.textContent = message;
  popup.classList.add('show');

  setTimeout(() => {
    popup.classList.remove('show');
  }, 2000); // popup verdwijnt na 2 seconden
}

// Favorieten toevoegen
function addToFavorites(name) {
  if (!favoritePokemons.includes(name)) {
    favoritePokemons.push(name);
    localStorage.setItem('favorites', JSON.stringify(favoritePokemons));
    showPopup(`${name} is toegevoegd aan je favorieten!`);
  } else {
    showPopup(`${name} staat al in je favorieten!`);
  }
}

// Favorieten verwijderen
function removeFromFavorites(name) {
  favoritePokemons = favoritePokemons.filter(p => p !== name);
  localStorage.setItem('favorites', JSON.stringify(favoritePokemons));
  showPopup(`${name} is verwijderd uit je favorieten!`);

  if (showingFavorites) {
    showFavorites();
  }
}

// Toon alleen favorieten met details
function showFavorites() {
  if (favoritePokemons.length === 0) {
    pokemonList.innerHTML = '<p>Je hebt nog geen favorieten toegevoegd.</p>';
    return;
  }

  // Zoek in allPokemons de url's van favorieten
  const favData = allPokemons.filter(p => favoritePokemons.includes(p.name));

  displayPokemons(favData);
}

// Sorteer Pokémon op naam
function sortPokemons(order = 'asc') {
  const sorted = [...allPokemons].sort((a, b) =>
    order === 'asc' ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name)
  );

  allPokemons = sorted;

  if (showingFavorites) {
    showFavorites();
  } else {
    displayPokemons(allPokemons);
  }
}

// Zoekfunctie
searchInput.addEventListener('input', (e) => {
  const search = e.target.value.toLowerCase();

  if (showingFavorites) {
    // Filter favorieten
    const filteredFavs = favoritePokemons.filter(name => name.includes(search));
    const filteredFavData = allPokemons.filter(p => filteredFavs.includes(p.name));
    displayPokemons(filteredFavData);
  } else {
    // Filter alle Pokémon
    const filtered = allPokemons.filter(p => p.name.includes(search));
    displayPokemons(filtered);
  }
});

// Sorteerknoppen
sortAscButton.addEventListener('click', () => sortPokemons('asc'));
sortDescButton.addEventListener('click', () => sortPokemons('desc'));

// Favorieten tonen knop toggle
toggleFavoritesBtn.addEventListener('click', () => {
  showingFavorites = !showingFavorites;
  toggleFavoritesBtn.textContent = showingFavorites ? '⬅️ Terug naar alle Pokémon' : '❤️ Favorieten tonen';

  if (showingFavorites) {
    showFavorites();
  } else {
    displayPokemons(allPokemons);
  }
});

//  BEGIN Winkelmandje functionaliteit 

// Winkelmandje data in localStorage of leeg
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Maak winkelmandje container + knop rechtsboven (fixed)
const cartDiv = document.createElement('div');
cartDiv.id = 'cart';
cartDiv.style.position = 'fixed';
cartDiv.style.top = '10px';
cartDiv.style.right = '10px';
cartDiv.style.backgroundColor = 'white';
cartDiv.style.border = '1px solid #ccc';
cartDiv.style.padding = '10px';
cartDiv.style.borderRadius = '5px';
cartDiv.style.width = '220px';
cartDiv.style.boxShadow = '0 0 10px rgba(0,0,0,0.2)';
cartDiv.style.zIndex = '1000';

// Winkelmand knop met teller
const cartBtn = document.createElement('button');
cartBtn.id = 'cart-btn';
cartBtn.textContent = `🛒 Winkelmandje (${cart.length})`;
cartBtn.style.width = '100%';
cartBtn.style.cursor = 'pointer';

// Winkelmand inhoud (verborgen)
const cartContent = document.createElement('div');
cartContent.id = 'cart-content';
cartContent.style.display = 'none';
cartContent.style.marginTop = '10px';
cartContent.style.maxHeight = '300px';
cartContent.style.overflowY = 'auto';
cartContent.style.fontSize = '14px';

cartDiv.appendChild(cartBtn);
cartDiv.appendChild(cartContent);
document.body.appendChild(cartDiv);

// Update winkelmand teller knop
function updateCartCount() {
  cartBtn.textContent = `🛒 Winkelmandje (${cart.length})`;
}

// Winkelmand toggle functie
function toggleCartContent() {
  if (cartContent.style.display === 'none') {
    if (cart.length === 0) {
      cartContent.innerHTML = '<p>Winkelmandje is leeg.</p>';
    } else {
      let totaal = 0;
      let listHtml = '<ul style="padding-left:20px; margin:0;">';
      cart.forEach((item, index) => {
        listHtml += `<li>${item.name} - €${item.price.toFixed(2)} <button data-index="${index}" style="margin-left:10px; cursor:pointer;">❌</button></li>`;
        totaal += item.price;
      });
      listHtml += `</ul><p><strong>Totaal: €${totaal.toFixed(2)}</strong></p>`;
      cartContent.innerHTML = listHtml;
    }
    cartContent.style.display = 'block';
  } else {
    cartContent.style.display = 'none';
  }
}

// Item aan winkelmand toevoegen
function addToCart(name, price) {
  cart.push({ name, price: parseFloat(price) });
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
  showPopup(`${name} is toegevoegd aan het winkelmandje!`);
}

// Item verwijderen uit winkelmandje
cartContent.addEventListener('click', e => {
  if (e.target.tagName === 'BUTTON' && e.target.hasAttribute('data-index')) {
    const index = parseInt(e.target.getAttribute('data-index'));
    if (!isNaN(index)) {
      const removed = cart.splice(index, 1)[0];
      localStorage.setItem('cart', JSON.stringify(cart));
      updateCartCount();
      showPopup(`${removed.name} is verwijderd uit winkelmandje!`);
      // Vernieuw inhoud winkelmandje
      toggleCartContent();
      toggleCartContent();
    }
  }
});

// Toggle winkelmandje zichtbaar/verborgen bij klikken op knop
cartBtn.addEventListener('click', toggleCartContent);

// EINDE Winkelmandje functionaliteit

// Start 
fetchPokemons().then(data => {
  allPokemons = data;
  displayPokemons(allPokemons);
});
